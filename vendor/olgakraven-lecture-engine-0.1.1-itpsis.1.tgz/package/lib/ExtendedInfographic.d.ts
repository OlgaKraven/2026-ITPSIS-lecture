import type { Visual } from './model';
export declare function ExtendedInfographic({ visual: v, marker, base }: {
    visual: Visual;
    marker: string;
    base: string;
}): import("react").JSX.Element | null;
