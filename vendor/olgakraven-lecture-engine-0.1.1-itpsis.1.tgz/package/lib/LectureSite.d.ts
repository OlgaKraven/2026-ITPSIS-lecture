import type { Course } from './model';
export declare function LectureSite({ course, base }: {
    course: Course;
    base?: string;
}): import("react").JSX.Element;
