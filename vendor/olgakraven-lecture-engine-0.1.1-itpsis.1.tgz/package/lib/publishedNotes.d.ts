import type { Course, Lecture, Note, TeacherPack } from './model';
export declare function validatePublishedNotes(value: unknown, course: Course, lecture: Lecture): TeacherPack;
export declare function mergeNotes(published: Record<string, Note>, legacy: Record<string, Note>, edits: Record<string, Partial<Note>>): Record<string, Note>;
